Snitzy Code Snippet: Optimized Search Page
Author:              OneWayMule
Date:                June 13, 2003
More info:           http://www.onewaymule.org/onewayscripts/forums/topic.asp?TOPIC_ID=35

Get more Snitzy Code Snippets at
http://www.onewaymule.org/onewayscripts/