Snitzy Code Snippet: Display Member ID In Posts
Author:              OneWayMule
Date:                March 31, 2003
More info:           http://www.onewaymule.org/onewayscripts/forums/topic.asp?TOPIC_ID=29

Get more Snitzy Code Snippets at
http://www.onewaymule.org/onewayscripts/