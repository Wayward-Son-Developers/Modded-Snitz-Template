function createxml(){
	var objxml=false;
	if(window.XMLHttpRequest){
		objXml=new XMLHttpRequest();
		if(objXml.overrideMimeType)objXml.overrideMimeType("text/xml");
	}else if(window.ActiveXObject){
		try{
			objXml=new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e){
			try{
				objXml=new ActiveXObject("Microsoft.XMLHTTP");
			}catch(e){}
		}
	}
	return objXml;
};
function openlink(url){
	win=window.open(url,"external");
	win.focus();
	return false;
};